#! /bin/sh

#aclocal \
#&& autoconf
autoreconf -fi
