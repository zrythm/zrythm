/** @defgroup thatgroup This is a group */

/**
@brief Function that's in a group
@ingroup thatgroup

Lines of detailed description that get merged to the brief for no freaking
reason.
*/
void foo();
