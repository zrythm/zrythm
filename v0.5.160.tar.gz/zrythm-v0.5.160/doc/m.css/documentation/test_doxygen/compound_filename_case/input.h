/** @mainpage

-   @subpage UPPERCASE
-   @ref UPPERCLASS
*/

/** @page UPPERCASE Uppercase page

This should get saved to a correct place and also get correctly linked to.
*/

/** @brief An uppercase class */
class UPPERCLASS {};
