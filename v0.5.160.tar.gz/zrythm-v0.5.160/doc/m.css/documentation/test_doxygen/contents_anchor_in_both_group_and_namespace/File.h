/** @defgroup fizzbuzz A group
@{ */

/*@}*/

/** @brief Foo */
namespace Foo {

/**
@brief Bar

@ingroup fizzbuzz

@anchor this_anchor

@link this_anchor More details @endlink
*/
void bar();

}
