/// First line of a brief output
/// @{
/// Second line of a brief output gets ignored with a warning
namespace Namespace {}
