/// ===============
/// The Thing
/// ===============
namespace Namespace {}
