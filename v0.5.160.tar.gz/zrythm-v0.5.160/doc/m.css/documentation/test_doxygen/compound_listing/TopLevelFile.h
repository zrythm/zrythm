/** @file
 * @brief Top-level file
 */

/** @brief Top-level class */
class TopLevelClass {};
