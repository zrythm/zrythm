Third-party components
######################

-   The ``m.math`` plugin makes use of the **latex2svg** utility ---
    https://github.com/tuxu/latex2svg, licensed under
    `MIT license <https://github.com/tuxu/latex2svg/blob/master/LICENSE.md>`_

Contributors to m.css
#####################

Listing only people with code contributions, because otherwise there's too many
:) Big thanks to everyone involved!

-   Arvid Gerstmann (`@Leandros <https://github.com/Leandros>`_) ---
    Windows-related fixes, bugreports
-   `@Bridouz <https://github.com/Bridouz>`_ --- documentation improvements
-   Cris Luengo (`@crisluengo <https://github.com/crisluengo>`_) ---
    complete handling of Doxygen entities and super/subscript elements
-   `@gotchafr <https://github.com/gotchafr>`_ --- Linux-related fixes
-   `@paulignari <https://github.com/paulignari>`_ --- i18n-related
    improvements
-   Ryohei Machida (`@machida-mn <https://github.com/machida-mn>`_) ---
    proof-of-concept implementation of ``#include`` information in the Doxygen
    theme
