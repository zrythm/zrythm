An Author
#########

:image: {static}/static/mosra.jpg
:badge: Info badge for `An Author <{author}an-author>`_ provided by the
    `Metadata <{filename}/plugins/metadata.rst>`_ plugin.

Detailed author info provided by the `Metadata <{filename}/plugins/metadata.rst>`_
plugin.
