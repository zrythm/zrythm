Artwork HOWTO
#############

favicon.svg
===========

Export as 16x16 PNG and convert to an ``*.ico``:

.. code:: sh

    convert favicon.png favicon.ico

magnifier.svg
=============

Doxygen search icon. Export as "Optimized SVG" and copy into the ``base.html``
template.
