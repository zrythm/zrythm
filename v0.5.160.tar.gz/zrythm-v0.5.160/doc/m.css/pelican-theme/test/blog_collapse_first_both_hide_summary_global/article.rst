An article
##########

:date: 2017-12-09
:collapse_first: False
:summary: The summary, shown nowhere.

The content, expanded on listing and on page.
