An article
##########

:date: 2017-12-09
:collapse_first: True
:summary: The summary, shown on listing.

The content, expanded only on page.
