An article
##########

:date: 2017-12-09
:hide_summary: True
:summary: The summary, shown neither in listing nor on the page.

The content, expanded fully both in listing and on the page.
