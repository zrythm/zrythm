An article — a jumbo one
########################

.. author is implicit
.. em-dash needs to be explicit as smart quotes are not enabled by default

:date: 2017-12-08
:category: Another category
:tags: Fourth, First, Third
:cover: {static}/ship.jpg
:summary: A summary.
    On multiple
    lines.

Some content.
