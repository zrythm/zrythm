An article
##########

:date: 2017-12-09
:category: A category
:tags: First, Third, Second
:author: Explicit Author
:description: Article description for the fake SEO believers.
:summary: The summary.
    On multiple
    lines.

The content, expanded fully on the page.
