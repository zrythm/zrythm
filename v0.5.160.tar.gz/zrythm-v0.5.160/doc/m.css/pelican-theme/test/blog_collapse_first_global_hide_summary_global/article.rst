An article
##########

:date: 2017-12-09
:summary: The summary, shown on listing.

The content, expanded only on page.
