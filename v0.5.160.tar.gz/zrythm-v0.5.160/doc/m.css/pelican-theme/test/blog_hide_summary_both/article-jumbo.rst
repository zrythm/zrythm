A jumbo article
###############

:date: 2017-12-08
:cover: image.jpg
:hide_summary: False
:summary: The summary, shown in both listing and on the page.

The content, expanded fully only on the page.
