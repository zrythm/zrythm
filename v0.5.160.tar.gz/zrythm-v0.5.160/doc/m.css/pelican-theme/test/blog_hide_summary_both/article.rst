An article
##########

:date: 2017-12-09
:hide_summary: False
:summary: The summary, repeated on the page.

The content, expanded fully both in the listing and on the page.
