An article
##########

:date: 2017-12-09
:summary: The summary.
:collapse_first: True

The content, not expanded.
