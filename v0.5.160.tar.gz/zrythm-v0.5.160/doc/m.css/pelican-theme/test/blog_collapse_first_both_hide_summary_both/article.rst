An article
##########

:date: 2017-12-09
:collapse_first: False
:hide_summary: False
:summary: The summary, expanded on both listing and page.

The content, expanded on listing and on page.
