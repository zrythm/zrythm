A jumbo article
###############

:date: 2017-12-08
:cover: image.jpg
:collapse_first: False
:hide_summary: False
:summary: Jumbo article summary, expanded on both listing and page.

The content, expanded only on page.
