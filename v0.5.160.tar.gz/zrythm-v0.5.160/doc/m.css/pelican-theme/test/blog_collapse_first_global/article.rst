An article
##########

:date: 2017-12-09
:summary: The summary.

The content, not expanded.
