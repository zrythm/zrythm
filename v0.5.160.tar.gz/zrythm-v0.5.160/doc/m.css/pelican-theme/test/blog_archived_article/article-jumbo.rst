A jumbo article
###############

:date: 1982-01-16
:cover: image.jpg
:archived: True

Article content.
