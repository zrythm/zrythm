An article
##########

:date: 1982-01-16
:archived: True

Article content.
