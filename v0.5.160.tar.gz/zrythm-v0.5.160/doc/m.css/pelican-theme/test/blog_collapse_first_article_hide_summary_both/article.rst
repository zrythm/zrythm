An article
##########

:date: 2017-12-09
:collapse_first: True
:hide_summary: False
:summary: The summary, expanded only on listing.

The content, expanded on listing and on page.
