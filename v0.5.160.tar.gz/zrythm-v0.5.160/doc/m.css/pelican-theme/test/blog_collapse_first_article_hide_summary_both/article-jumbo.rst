A jumbo article
###############

:date: 2017-12-08
:cover: image.jpg
:collapse_first: True
:hide_summary: False
:summary: Jumbo article summary, expanded only on listing.

The content, expanded only on page.

