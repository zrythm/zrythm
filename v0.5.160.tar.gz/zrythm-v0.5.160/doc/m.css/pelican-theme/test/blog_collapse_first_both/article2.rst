An article 2
############

:date: 2017-12-08
:summary: Article 2 summary.
:collapse_first: False

The content, not expanded as this is a second article.
