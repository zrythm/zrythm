An article
##########

:date: 2017-12-09
:summary: The summary.
:collapse_first: False

The content, expanded fully on the page.
