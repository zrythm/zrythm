An article
##########

:date: 2017-12-09
:collapse_first: False
:hide_summary: True
:summary: The summary, shown nowhere.

The content, expanded on listing and on page.
