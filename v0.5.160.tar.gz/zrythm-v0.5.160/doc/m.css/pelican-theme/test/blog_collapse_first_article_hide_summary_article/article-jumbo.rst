A jumbo article
###############

:date: 2017-12-08
:cover: image.jpg
:collapse_first: True
:hide_summary: True
:summary: Jumbo article summary, shown only on listing.

The content, expanded only on page.
